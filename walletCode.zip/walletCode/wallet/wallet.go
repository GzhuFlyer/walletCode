package wallet

import (
	"errors"
	"fmt"
	"sync"
)

// User represents a user in the wallet system.
type User struct {
	ID     string
	Wallet *Wallet
}

// Wallet represents a user's wallet containing a balance.
type Wallet struct {
	Balance float64
	mu      sync.Mutex
}

// WalletApp represents the wallet application containing multiple users.
type WalletApp struct {
	users map[string]*User
	mu    sync.Mutex
}

// NewWalletApp creates a new instance of WalletApp.
func NewWalletApp() *WalletApp {
	return &WalletApp{
		users: make(map[string]*User),
	}
}

// CreateUser creates a new user and wallet in the system.
func (app *WalletApp) CreateUser(id string) (*User, error) {
	app.mu.Lock()
	defer app.mu.Unlock()

	if _, exists := app.users[id]; exists {
		return nil, errors.New("user already exists")
	}

	user := &User{
		ID:     id,
		Wallet: &Wallet{},
	}
	app.users[id] = user
	return user, nil
}

// Deposit allows the user to deposit money into their wallet.
func (w *Wallet) Deposit(amount float64) error {
	if amount <= 0 {
		return errors.New("amount must be positive")
	}
	w.mu.Lock()
	defer w.mu.Unlock()
	w.Balance += amount
	return nil
}

// Withdraw allows the user to withdraw money from their wallet.
func (w *Wallet) Withdraw(amount float64) error {
	w.mu.Lock()
	defer w.mu.Unlock()

	if amount <= 0 {
		return errors.New("amount must be positive")
	}
	if amount > w.Balance {
		return errors.New("insufficient funds")
	}

	w.Balance -= amount
	return nil
}

// Transfer allows a user to transfer money to another user's wallet.
func (app *WalletApp) Transfer(fromID, toID string, amount float64) error {
	app.mu.Lock()
	fromUser, fromExists := app.users[fromID]
	toUser, toExists := app.users[toID]
	app.mu.Unlock()

	if !fromExists || !toExists {
		return errors.New("one or both users not found")
	}

	if amount <= 0 {
		return errors.New("amount must be positive")
	}

	fromUser.Wallet.mu.Lock()
	defer fromUser.Wallet.mu.Unlock()

	toUser.Wallet.mu.Lock()
	defer toUser.Wallet.mu.Unlock()

	if fromUser.Wallet.Balance < amount {
		return errors.New("insufficient funds")
	}

	fromUser.Wallet.Balance -= amount
	toUser.Wallet.Balance += amount

	return nil
}

// CheckBalance allows the user to check their wallet balance.
func (w *Wallet) CheckBalance() float64 {
	w.mu.Lock()
	defer w.mu.Unlock()
	return w.Balance
}

// GetUser retrieves a user by ID.
func (app *WalletApp) GetUser(id string) (*User, error) {
	app.mu.Lock()
	defer app.mu.Unlock()

	user, exists := app.users[id]
	if !exists {
		return nil, errors.New("user not found")
	}
	return user, nil
}

// DisplayUserInfo displays a user's ID and balance.
func (user *User) DisplayUserInfo() {
	fmt.Printf("User ID: %s, Balance: %.2f\n", user.ID, user.Wallet.CheckBalance())
}
