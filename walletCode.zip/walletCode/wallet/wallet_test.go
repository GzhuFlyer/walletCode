package wallet

import (
	"testing"
)

func TestCreateUser(t *testing.T) {
	app := NewWalletApp()
	user, err := app.CreateUser("user1")
	if err != nil {
		t.Fatalf("expected no error, got %v", err)
	}
	if user.ID != "user1" {
		t.Fatalf("expected user ID 'user1', got %s", user.ID)
	}
}

func TestDeposit(t *testing.T) {
	app := NewWalletApp()
	user, _ := app.CreateUser("user1")

	err := user.Wallet.Deposit(100)
	if err != nil {
		t.Fatalf("expected no error, got %v", err)
	}

	balance := user.Wallet.CheckBalance()
	if balance != 100 {
		t.Fatalf("expected balance 100, got %.2f", balance)
	}
}

func TestWithdraw(t *testing.T) {
	app := NewWalletApp()
	user, _ := app.CreateUser("user1")

	user.Wallet.Deposit(100)
	err := user.Wallet.Withdraw(50)
	if err != nil {
		t.Fatalf("expected no error, got %v", err)
	}

	balance := user.Wallet.CheckBalance()
	if balance != 50 {
		t.Fatalf("expected balance 50, got %.2f", balance)
	}
}

func TestTransfer(t *testing.T) {
	app := NewWalletApp()
	user1, _ := app.CreateUser("user1")
	user2, _ := app.CreateUser("user2")

	user1.Wallet.Deposit(100)
	err := app.Transfer("user1", "user2", 50)
	if err != nil {
		t.Fatalf("expected no error, got %v", err)
	}

	balance1 := user1.Wallet.CheckBalance()
	balance2 := user2.Wallet.CheckBalance()

	if balance1 != 50 || balance2 != 50 {
		t.Fatalf("expected user1 balance 50 and user2 balance 50, got %.2f and %.2f", balance1, balance2)
	}
}
