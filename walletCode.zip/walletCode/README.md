# Wallet Application

## Design Decisions
- **Thread Safety**: The `Wallet` struct is designed to be thread-safe by utilizing a `sync.Mutex`. This ensures that concurrent access to the wallet balance is properly synchronized and avoids race conditions.
- **In-memory Storage**: Users and their wallets are stored in-memory using a `map`, with each user being tracked by their unique ID. This design allows fast lookups but is temporary and will not persist data between application runs.

markdown
复制代码
# Wallet Application

## Setup and Run Instructions

#### 1. Clone the Repository
First, clone this repository to your local machine and navigate to the project directory:
```bash
git clone <repository-url>
cd wallet-app
```
#### 2. Install Go
Ensure that you have Go installed on your system. You can download and install Go from the official website: Golang Install.

#### 3. Build the Project
After cloning the repository, you can build the project by running:

```bash
复制代码
go build
```
#### 4. Running Tests
To run the unit tests and ensure everything is working correctly, execute:
```
go test ./...
```

#### 5. Running the Application
Once the project is built, you can start the application by running the binary:
```
./walletCode
```
#### 6. Interacting with the Application
Since this is a backend service with no UI, you can interact with the wallet functionality programmatically. Example usage can be found in main.go, or you can create your own implementation by calling the following methods:

Deposit(amount float64) – to add money to a wallet
Withdraw(amount float64) – to withdraw money
Transfer(fromUserID string, toUserID string, amount float64) – to transfer money between users
CheckBalance() – to view the wallet balance
For detailed examples, refer to the code or the test cases.

Additional Resources
If you encounter issues or need further assistance, check out the Go Documentation.


## Time Spent
- **Planning**: 30 minutes
- **Coding**: 1.5 hours
- **Testing**: 30 minutes
- **Documentation**: 20 minutes

## Improvements
- **Persistence**: Add a database to store users and transactions, ensuring that data is persisted beyond application restarts.
- **Precision**: Improve handling of floating-point precision for financial transactions to prevent rounding errors.
- **Logging**: Implement a logging mechanism for better traceability and debugging.
- **Security**: Introduce additional security measures, such as transaction limits, to protect against potential abuse or misuse.
