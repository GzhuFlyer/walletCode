package main

import (
	"fmt"
	"log"
	"walletCode/wallet"
)

func main() {
	// Create a wallet application instance
	app := wallet.NewWalletApp()

	// Create two users
	user1, err := app.CreateUser("user1")
	if err != nil {
		log.Fatalf("Failed to create user: %v", err)
	}

	user2, err := app.CreateUser("user2")
	if err != nil {
		log.Fatalf("Failed to create user: %v", err)
	}

	// User 1 deposits money
	err = user1.Wallet.Deposit(200)
	if err != nil {
		log.Fatalf("Deposit failed: %v", err)
	}

	// Display User 1's balance
	user1.DisplayUserInfo() // Output: User ID: user1, Balance: 200.00

	// User 1 withdraws money
	err = user1.Wallet.Withdraw(50)
	if err != nil {
		log.Fatalf("Withdraw failed: %v", err)
	}

	// Display User 1's balance
	user1.DisplayUserInfo() // Output: User ID: user1, Balance: 150.00

	// User 1 transfers money to User 2
	err = app.Transfer("user1", "user2", 100)
	if err != nil {
		log.Fatalf("Transfer failed: %v", err)
	}

	// Display User 1 and User 2's balances
	user1.DisplayUserInfo() // Output: User ID: user1, Balance: 50.00
	user2.DisplayUserInfo() // Output: User ID: user2, Balance: 100.00

	// Check User 2's balance
	fmt.Printf("User 2's balance: %.2f\n", user2.Wallet.CheckBalance()) // Output: User 2's balance: 100.00
}
